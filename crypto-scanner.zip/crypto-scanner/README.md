# Signal Scanner — Crypto Trade Setups

A live crypto trade signal dashboard with long/short setups, stop losses, volume profile, OI, and Claude AI analysis.

---

## What you get
- Live prices from Binance + CoinGecko (real tick data)
- Long & short setups with ATR-based stop losses and take profit targets
- Volume profile, open interest, funding rates
- RSI, EMA trend structure, Fear & Greed
- Claude AI analysis — bull/bear case, key risk, historical pattern, suggested action
- High-conviction alerts when score hits 7+
- BTC, ETH, SOL, XRP, SUI — 1D / 4H / 1H / 15M timeframes

---

## Deploy in ~15 minutes

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Sign up or log in
3. Click "API Keys" → "Create Key"
4. Copy the key (starts with `sk-ant-...`)
5. Set a spending limit: go to Billing → Usage Limits → set $20/month max

### Step 2 — Put the code on GitHub
1. Go to https://github.com and create a free account if you don't have one
2. Click the "+" button → "New repository"
3. Name it `crypto-scanner`, set to Private, click Create
4. Click "uploading an existing file"
5. Upload the entire `crypto-scanner` folder (drag and drop works)
6. Click "Commit changes"

### Step 3 — Deploy on Vercel (free)
1. Go to https://vercel.com and sign up with your GitHub account
2. Click "Add New Project"
3. Select your `crypto-scanner` repository
4. Click "Deploy" — Vercel auto-detects the settings

### Step 4 — Add your API key (keeps it secure)
1. In Vercel, go to your project → Settings → Environment Variables
2. Add a new variable:
   - Name:  `ANTHROPIC_API_KEY`
   - Value: `sk-ant-your-key-here`
3. Click Save
4. Go to Deployments → click the three dots → Redeploy

### Step 5 — Done
Your app is live at `https://crypto-scanner-yourname.vercel.app`

Bookmark it on your phone. Open it on any device.

---

## Cost estimate
- Vercel hosting: **Free**
- Binance API: **Free** (no key needed for public endpoints)
- CoinGecko API: **Free** (rate limited, fine for personal use)
- Alternative.me Fear & Greed: **Free**
- Anthropic API: **~$3–8/month** at typical usage (AI analysis per coin per session)

---

## File structure
```
crypto-scanner/
├── vercel.json          # Vercel routing config
├── public/
│   └── index.html       # Full frontend app
└── api/
    └── analyze.js       # Serverless function — Claude AI analysis (keeps API key secure)
```

---

## Customizing
- Add more coins: edit the `COINS` object in `index.html`
- Change alert threshold: edit `alertThreshold` (currently 7/10)
- Adjust stop loss multiplier: edit `atr * 1.5` in `calcSetups()` (higher = wider stop)
- Adjust TP multiplier: edit `atr * 2.0` and `atr * 3.5`

---

## Notes
- Binance futures endpoints (funding rate, OI) only work for coins with perpetual futures
- CoinGecko free tier has rate limits — if you get errors, wait 60 seconds and refresh
- The AI analysis is cached per session so you're not charged on every click
- Not financial advice. Always manage your own risk.
